package com.jpmc.entitlement.test;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
//import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

//@Path here defines class level path. Identifies the URI path that 
//a resource class will serve requests for.
@Path("UserInformationService")
public class UserInformation {

//@GET here defines, this method will method will process HTTP GET
//requests.
@GET
//@Path here defines method level path. Identifies the URI path that a
//resource class method will serve requests for.
@Path("/user")
//@Produces here defines the media type(s) that the methods
//of a resource class can produce.
@Produces(MediaType.TEXT_HTML)
//@PathParam injects the value of URI parameter that defined in @Path
//expression, into the method.

public String userName() {
	
	StringBuilder jsonString = new StringBuilder();
	
	jsonString.append("{");
	//jsonString.append("\"success\" : \"true\"");
	//jsonString.append(",");
	jsonString.append("\"data\" :[{");
	jsonString.append("\"name\" : \"CABLE, JOSEPH D (B002935)\",");
	jsonString.append("\"title\" : \"SUPERVISORY MANAGER (Not Yet Defined)\",");
	jsonString.append("\"lob\" : \"CPC\",");
	jsonString.append("\"manager\" : \"KENNETH R BARHAUG (U043401)\",");
	jsonString.append("\"location\" : \"COLUMBUS, OH\",");
	
	/*jsonString.append("\"bank\" : \"Wealth Mgmt(USA)\",");
	jsonString.append("\"group\" : \"Alternative Assets\",");
	jsonString.append("\"role\" : \"Analyst\",");
	jsonString.append("\"status\" : \"Added\",");
	jsonString.append("\"action\" : \"Remove\",");*/
	
	jsonString.append("}");
	
	jsonString.append("]}");
	
	
	System.out.println(jsonString);
	return jsonString.toString();
	

}

}
