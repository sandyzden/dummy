Ext.define('Entitlement.store.EmployeeRoleListStore', {
    extend: 'Ext.data.Store',
    model: 'Entitlement.model.EmployeeRoleListModel',
    autoLoad : false,
    sorters : {
    	property : 'lob',
    	direction : 'ASC'
    },
    proxy: {
		type: 'ajax',
		reader: {
			type: 'json',
			root: 'data'
		},
		url: 'data/roleList.json'
	} 
});