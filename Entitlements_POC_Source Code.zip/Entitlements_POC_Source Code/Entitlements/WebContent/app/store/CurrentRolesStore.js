Ext.define('Entitlement.store.CurrentRolesStore', {
    extend: 'Ext.data.Store',
    model: 'Entitlement.model.CurrentRolesModel',
    autoLoad : false,
    sorters : {
    	property : 'lob',
    	direction : 'ASC'
    },
    proxy: {
		type: 'ajax',
		reader: {
			type: 'json',
			root: 'data'
		},
		url:  'data/roleLists.json' /*'rest/UserInfoService/users'*/
	} 
});