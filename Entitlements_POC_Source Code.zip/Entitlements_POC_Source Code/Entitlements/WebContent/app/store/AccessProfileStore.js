Ext.define('Entitlement.store.AccessProfileStore', {
    extend: 'Ext.data.Store',
    model: 'Entitlement.model.AccessProfileModel',
    autoLoad : false,
  /*  sorters : {
    	property : 'lob',
    	direction : 'ASC'
    },
    proxy: {
		type: 'ajax',
		reader: {
			type: 'json',
			root: 'data'
		},
		url: 'data/bankStatus.json'
	} */
});