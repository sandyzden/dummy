Ext.define('Entitlement.store.EmployeeSearchStore', {
    extend: 'Ext.data.Store',
    model: 'Entitlement.model.EmployeeSearchModel',
    autoLoad : false,
    sorters : {
    	property : 'name',
    	direction : 'ASC'
    },
    proxy: {
		type: 'ajax',
		reader: {
			type: 'json',
			root: 'data'
		},
		url: 'rest/UserInformationService/user'
	} 
});