Ext.define('Entitlement.store.CurrentAccessStore', {
    extend: 'Ext.data.Store',
    model: 'Entitlement.model.CurrentAccessModel',
    autoLoad : true,
    sorters : {
    	property : 'lob',
    	direction : 'ASC'
    },
    proxy: {
		type: 'ajax',
		reader: {
			type: 'json',
			root: 'data'
		},
		url: 'data/currentAccessStatus.json'
	} 
});