Ext.define('Entitlement.store.CurrentWorkflowStore', {
    extend: 'Ext.data.Store',
    model: 'Entitlement.model.CurrentWorkflowModel',
    autoLoad : true,
  sorters : {
    	property : 'bank',
    	direction : 'ASC'
    },
    proxy: {
		type: 'ajax',
		reader: {
			type: 'json',
			root: 'data'
		},
		url: 'data/currentWorkflow.json'
	} 
});