Ext.define('Entitlement.view.EmployeeOrganizationListGrid' ,{
    extend: 'Ext.grid.Panel',
    alias: 'widget.employeeOrganizationListGrid',
    cls : 'gridHeader',
    title: 'Organizations:',
    store : 'EmployeeOrganizationListStore',  
    columnLines : true,
    initComponent: function() {

        this.columns = [
            {header: 'Bank',  dataIndex: 'bank',  flex: 1},
            {header: 'Path',  dataIndex: 'path',  flex: 1},
            {header: 'Org/Team',  dataIndex: 'orgTeam',  flex: 1.5},
            {header: 'Type',  dataIndex: 'type',  flex: 0.75},
            {header: 'Name',  dataIndex: 'name',  flex: 0.75},
            {header: 'Status',  dataIndex: 'status',  flex: 1},
            {header: 'Action', dataIndex: 'action', flex: 1}
        ];

        this.callParent(arguments);
    }
});