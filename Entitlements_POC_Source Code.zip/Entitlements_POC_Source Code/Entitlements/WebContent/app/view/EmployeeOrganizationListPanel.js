Ext.define('Entitlement.view.EmployeeOrganizationListPanel' ,{
    extend: 'Ext.panel.Panel',
    alias: 'widget.employeeOrganizationListPanel',
    title: 'Employee Organization List',
    cls : 'panelHeader',
    collapsible : true,
    tools : [{
    	type : 'help'
    },{
    	type : 'maximize'
    }],
    initComponent: function() {

        this.items = [{
        	xtype : 'employeeOrganizationListGrid'
        }];

        this.callParent(arguments);
    }
});