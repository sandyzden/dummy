Ext.define('Entitlement.view.EmployeeTeamListPanel' ,{
    extend: 'Ext.panel.Panel',
    alias: 'widget.employeeTeamListPanel',
    title: 'Employee Team List',
    cls : 'panelHeader',
    collapsible : true,
    tools : [{
    	type : 'help'
    },{
    	type : 'maximize'
    }],
    initComponent: function() {

        this.items = [{
        	xtype : 'employeeTeamListGrid'
        }];

        this.callParent(arguments);
    }
});