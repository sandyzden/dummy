Ext.Loader.setConfig({
	enabled : true
});
Ext.Loader.setPath('Ext.ux', 'ext/extjs-4.1.1/ux');

Ext.require([ 'Ext.ux.grid.FiltersFeature',
              'Ext.util.*',
              'Ext.state.*']);

Ext.define('Entitlement.view.EmployeeSearchGrid' ,{
    extend: 'Ext.grid.Panel',
    alias: 'widget.employeeSearchGrid',
    cls : 'gridHeader',
    title: 'Search Results: (to view Employee, click the name. to view Manager, click the name)',
    store : 'EmployeeSearchStore',
	stateful : true,
	stateId : 'savepreferenceGrid',
    columnLines : true,
	applyState: function( state ) { 
               var me=this, 
               columns=me.columns;  // this is needed because base setState - destroy this columns 
               me.fstate=state;        // this will be the state for the feature which do not get the event  
               me.callParent(arguments); 
               me.columns=columns;  // now base class have done it work and we restore the columns  
           },  
    initComponent: function() {
		var filtersCfg = {
								ftype : 'filters',
								local : true,
								stateId : 'savepreferenceGridFilters'
							};
		
		this.features = [ filtersCfg ];
							
        this.columns = [
            {header: 'Name', dataIndex: 'name', flex: 1, filterable : true},
            {header: 'Title (Business Role)',  dataIndex: 'title',  flex: 3},
            {header: 'LOB',  dataIndex: 'lob',  flex: 0.5},
            {header: 'Manager',  dataIndex: 'manager',  flex: 1},
            {header: 'Location', dataIndex: 'location', flex: 1}
        ];
        
        this.dockedItems = [{
        	xtype: 'pagingtoolbar',
            store: 'EmployeeSearchStore',  
            dock: 'bottom',
            displayInfo: true
        }];

        this.callParent(arguments);
    }
});