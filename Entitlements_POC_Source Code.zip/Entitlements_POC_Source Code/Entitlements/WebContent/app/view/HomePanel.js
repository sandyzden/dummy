Ext.define('Entitlement.view.HomePanel' ,{
    extend: 'Ext.panel.Panel',
    alias: 'widget.homePanel',
    initComponent: function() {

        this.items = [{
        	xtype : 'headerPanel',
        	cls  : 'headerPnl'
        },{
        	xtype : 'mainTabPanel',
        	id : 'mainTabPnl'
        }];

        this.callParent(arguments);
    }
});