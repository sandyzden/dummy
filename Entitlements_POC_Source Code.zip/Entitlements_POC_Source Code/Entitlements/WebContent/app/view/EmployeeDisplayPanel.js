var statew = Ext.create('Ext.data.Store', {
    fields: ['abbrs', 'action'],
    data : [
        {"abbrs":"AR", "action":"Select an Action"},   
        {"abbrs":"AS", "action":"Update Employee"},
        {"abbrs":"AT", "action":"View Employee Activity"}
 
    ]
});

Ext.define('Entitlement.view.EmployeeDisplayPanel' ,{
    extend: 'Ext.panel.Panel',
    alias: 'widget.employeeDisplayPanel',
    title: 'Employee Display',
    cls : 'panelHeader',
    collapsible : true,
    tools : [{
    	type : 'help'
    },{
    	type : 'maximize'
    }],
    initComponent: function() {

        this.dockedItems = [{
        	xtype:'container',
        	dock: 'top',
        	layout: 'hbox',
        	
       items : [{								
                      
             
        	xtype: 'displayfield',
        	cls : 'labelCls',
        	id : 'employeeDetail',
        	labelWidth : 130,
        	fieldLabel : 'Details for Employee'
        },
        {
        	xtype : 'tbfill'
        },
        {
            xtype: 'combobox',
            flex: 0.3,
            allowBlank: false,
            //fieldLabel: 'Details for Employee',
            store: statew,
           // width: '200%',
            id : 'employeeDetail2',
            disabled : true,
            emptyText : 'Select an Action',
            labelAlign  : 'right',
            labelWidth : 130,
            displayField : 'action',
            valueField: 'abbrs',
            listeners: {
            		 change: function(btn){
            			 Ext.getCmp('pnlEmployeeHome').getLayout().setActiveItem(1);
            			 Ext.getCmp('employeeDetail2').reset();
            			// alert("hello"); 
            			 //Ext.getCmp('accessContainer').getLayout().setActiveItem(1);
            			 }
            	
            }
            //labelWidth: 200
            //width : 180
            
        }]
        }];
        this.items	= [{
     
        
        	xtype : 'employeeDetailsForm',
        	widtth : '100%'
        },{
        	xtype : 'bankStatusGrid'
        },{
        	xtype : 'sensitiveClientGrid'
        }];

        this.callParent(arguments);
    }
});