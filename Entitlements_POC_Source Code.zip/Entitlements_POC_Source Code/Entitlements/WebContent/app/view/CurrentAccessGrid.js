Ext.Loader.setConfig({
	enabled : true
});
Ext.Loader.setPath('Ext.ux', 'ext/extjs-4.1.1/ux');
Ext.require([ 'Ext.ux.grid.FiltersFeature']);

Ext.define('Entitlement.view.CurrentAccessGrid' ,{
    extend: 'Ext.grid.Panel',
    alias: 'widget.currentAccessGrid',
    cls : 'gridHeader',
    title: 'Current Access:',
    store : 'CurrentAccessStore',  
    columnLines : true,
    overflowY: 'auto',
	maxHeight: 200,
 
    initComponent: function() {
    	var filtersCfg = {
    			ftype : 'filters',
    			autoReload : false,
    			encode : true,
    			local : false
    		};
    	this.features = [ filtersCfg ];
        this.columns = [
            {header: 'LOB', dataIndex: 'lob', flex: 2,locked : true,filterable : true},
            {header: 'Bank',  dataIndex: 'bank',  flex: 2,filterable : true},
            {header: 'Entitlement',  dataIndex: 'entitlement',  flex: 1},
            {header: 'Status',  dataIndex: 'status',  flex: 1},
            {header: 'Action', dataIndex: 'action', flex: 1}
        ];

        this.callParent(arguments);
    }
});