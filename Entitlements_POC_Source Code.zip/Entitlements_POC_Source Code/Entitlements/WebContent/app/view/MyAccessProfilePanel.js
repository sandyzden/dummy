Ext.define('Entitlement.view.MyAccessProfilePanel' ,{
    extend: 'Ext.panel.Panel',
    alias: 'widget.myAccessProfilePanel',
    title: 'My Access Profile',
    cls : 'panelHeader',
    collapsible : true,
    tools : [{
    	type : 'help'
    },{
    	type : 'maximize'
    }],
    initComponent: function() {

        this.items = [{
        	xtype : 'myAccessProfileGrid',
        	
        	id: 'myAccessProfileGrid'
        },
        {
        	xtype : 'myCurrentRolesGrid',
        	id:'myCurrentRolesGrid'
        }];
        
      
        this.callParent(arguments);
    }
});