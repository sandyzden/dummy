var searchBy = Ext.create('Ext.data.Store', {
    fields: ['abbr', 'name'],
    data : [
        {"value":"lName_fName", "name":"Last Name,First Name"},
        {"value":"fName_lName", "name":"First Name,Last Name"},
        {"value":"fName_mName_lName", "name":"First Name Middle Name Last Name"},
        {"value":"sid", "name":"Standard Id"}
    ]
});

Ext.define('Entitlement.view.EmployeeSearchPanel' ,{
    extend: 'Ext.panel.Panel',
    alias: 'widget.employeeSearchPanel',
    title: 'Employee Search',
    cls : 'panelHeader',
    collapsible : true,
    tools : [{
    	type : 'help'
    },{
    	type : 'maximize'
    }],
    initComponent: function() {

        this.items = [{
        	xtype : 'form',
        	id : 'employeeSearchForm',
        	margin: '5 0 5 0',
        	frame : false,
        	border : false,
        	layout : {
        		type : 'hbox'
        	},
        	items : [{
        		xtype : 'combo',
        		fieldLabel: 'Search for Employee by',
        	    store: searchBy,
        	    queryMode: 'local',
        	    displayField: 'name',
        	    valueField: 'value',
        	    id : 'searchByField',
        	    editable : false ,
        	    labelWidth : 150,
        	    width : '30%',
        	    margin : '0 10 0 0'
        	},{
        		xtype : 'textfield',
        		height : 22,
        		vtype : 'alphanum',
        		margin : '0 10 0 0'
        		
        	},{
        		xtype : 'button',
        		text : 'Search',
        		id : 'searchEmployee',
        		handler : function(){
        			
					/*var id= Ext.util.Cookies.get('ext-savepreferenceGrid');
					console.log(id);*/
        			//Ext.ComponentQuery.query('#employeeSearchGrid')[0].getStore().load();
        			 Ext.getStore('BankStatusStore').load();
        			Ext.getStore('SensitiveClientStore').load();
        			Ext.getStore('EmployeeRoleListStore').load();
        			
        			Ext.getCmp('employeeDetail').setValue('JOSEPH D CABLE (B002935)');
        			Ext.getCmp('hrTitle').setValue('SUPERVISORY MANAGER');
        			Ext.getCmp('businessRole').setValue('Not Yet Defined (9999)');
        			Ext.getCmp('phone').setValue('614/901-1403 ');
        			Ext.getCmp('email').setValue('JOSEPH.D.CABLE@CHASE.COM ');
        			Ext.getCmp('hrType').setValue('Employee ');
        			Ext.getCmp('hrStatus').setValue('Active ');
        			Ext.getCmp('mailCode').setValue('OH1-1208 ');
        			Ext.getCmp('streetAddress').setValue('1111 POLARIS PARKWAY , COLUMBUS, OH 432402050');
        			Ext.getCmp('lineOfBusiness').setValue('CPC (HR: CCB W/O CARD)');
        			Ext.getCmp('costCenter').setValue('135594');
        			Ext.getCmp('jobCode').setValue('PM0102');
        			Ext.getCmp('manager').setValue('KENNETH R BARHAUG (U043401)'); 
        			
        			
        		}
        	}]
        },{
        	xtype : 'employeeSearchGrid',
        	id: 'employeeSearchGrid'
        }];

        this.callParent(arguments);
    }
});