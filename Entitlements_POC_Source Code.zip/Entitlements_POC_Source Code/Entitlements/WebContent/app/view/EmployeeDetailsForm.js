Ext.define('Entitlement.view.EmployeeDetailsForm' ,{
    extend: 'Ext.panel.Panel',
    alias: 'widget.employeeDetailsForm',
    bodyPadding: '5 5 0',
    layout: 'hbox',
    initComponent: function() {

        this.items = [{
        	xtype : 'form',
        	width : '50%',
        	margin : '0 0 0 10',
        	layout  : 'anchor',
        	cls : 'hrForm',
        	fieldDefaults: {
        	        labelAlign: 'right',
        	        msgTarget: 'side',
        	        anchor : '90%',
        	        readOnly : true
        	 },
        	items : [{
            	xtype : 'displayfield',
            	id : 'hrTitle',
            	fieldLabel : 'HR Title'
            },{
            	xtype : 'menuseparator',
            	width : '100%'
            },{
            	xtype : 'displayfield',
            	id : 'businessRole',
            	fieldLabel : 'Business Role'
            },{
            	xtype : 'menuseparator',
            	width : '100%'
            },{
            	xtype : 'displayfield',
            	id : 'phone',
            	fieldLabel : 'Phone'
            },{
            	xtype : 'menuseparator',
            	width : '100%'
            },{
            	xtype : 'displayfield',
            	id : 'email',
            	fieldLabel : 'Email'
            },{
            	xtype : 'menuseparator',
            	width : '100%'
            },{
            	xtype : 'displayfield',
            	id : 'hrType',
            	fieldLabel : 'HR Type'
            },{
            	xtype : 'menuseparator',
            	width : '100%'
            },{
            	xtype : 'displayfield',
            	id : 'hrStatus',
            	fieldLabel : 'HR Status'
            }]
        },{
        	xtype : 'form',
        	width : '49%',
        	layout  : 'anchor',
        	cls : 'contactForm',
        	fieldDefaults: {
        		 	labelAlign: 'right',
        	        msgTarget: 'side',
        	        anchor : '90%',
        	        readOnly : true
        	 },
        	items : [{
            	xtype : 'displayfield',
            	id : 'mailCode',
            	fieldLabel : 'Mail Code'
            },{
            	xtype : 'menuseparator',
            	width : '100%'
            },{
            	xtype : 'displayfield',
            	id: 'streetAddress',
            	fieldLabel : 'Street Address'
            },{
            	xtype : 'menuseparator',
            	width : '100%'
            },{
            	xtype : 'displayfield',
            	id : 'lineOfBusiness',
            	fieldLabel : 'Line of Business'
            },{
            	xtype : 'menuseparator',
            	width : '100%'
            },{
            	xtype : 'displayfield',
            	id : 'costCenter',
            	fieldLabel : 'Cost Center'
            },{
            	xtype : 'menuseparator',
            	width : '100%'
            },{
            	xtype : 'displayfield',
            	id : 'jobCode',
            	fieldLabel : 'Job Code'
            },{
            	xtype : 'menuseparator',
            	width : '100%'
            },{
            	xtype : 'displayfield',
            	id : 'manager',
            	fieldLabel : 'Manager'
            }]
        }];

        this.callParent(arguments);
    }
});