Ext.define('Entitlement.view.CurrentRolesGrid' ,{
    extend: 'Ext.grid.Panel',
    alias: 'widget.currentRolesGrid',
    cls : 'gridHeader',
    title: 'Current Roles:',
    store : 'CurrentRolesStore',  
    columnLines : true,
    initComponent: function() {

        this.columns = [
            {header: 'LOB',  dataIndex: 'lob',  flex: 1},
            {header: 'Bank', dataIndex: 'bank', flex: 1},
            {header: 'Group', dataIndex: 'group', flex: 1},
            {header: 'Role', dataIndex: 'role', flex: 2},
            {header: 'Status',  dataIndex: 'status',  flex: 1},
            {header: 'Action', dataIndex: 'action', flex: 1}
        ];

        this.callParent(arguments);
    }
});