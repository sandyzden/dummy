Ext.define('Entitlement.view.MainTabPanel' ,{
    extend: 'Ext.tab.Panel',
    alias: 'widget.mainTabPanel',
    layout : 'card',
    border : false,
    frame : false,
    initComponent: function() {
    	this.items = [{
    		title : 'Access',
    		items : [{
    			xtype : 'accessSubTabPanel',
    			id : 'accessSubTabPnl'
    		}]
    	},{
    		title : 'Approvals'
    	},    	{
    		title : 'Client Coverage'
    	},{
    		title : 'Deployed Components'
    	},{
    		title : 'Coverage Approvals'
    	}];

        this.callParent(arguments);
    }
});