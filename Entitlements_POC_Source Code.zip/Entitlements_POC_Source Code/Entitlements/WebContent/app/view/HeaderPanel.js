Ext.define('Entitlement.view.HeaderPanel' ,{
    extend: 'Ext.panel.Panel',
    alias: 'widget.headerPanel',
    layout: {
        type: 'hbox'
    },
    defaults : {
    	margin : '10 10 10 10'
    },
    initComponent: function() {

        this.items = [{
        	xtype : 'label',
        	cls : 'headerTxtCls',
        	text : 'Workstation'
        },{
        	xtype: 'tbfill'
        },{
        	xtype : 'button',
        	text : 'F7'
        },{
        	xtype : 'button',
        	text : 'Log Out',
        	margin : '10 20 10 10',
        	menu : [{
    			xtype : 'container',
    			layout : 'hbox',
    			width : 500,
    			height : 250,
    			items : [{
    				xtype :'textfield',
    				fieldLabel : 'Search'
    			},{
    				xtype : 'button',
    				text : 'search',
    				handler : function(){
    					Ext.ComponentQuery.query('#employeeSearchGrid')[0].getStore().load();
            			Ext.getStore('BankStatusStore').load();
            			Ext.getStore('SensitiveClientStore').load();
            			Ext.getStore('EmployeeRoleListStore').load();
            			
            			Ext.getCmp('employeeDetail').setValue('JOSEPH D CABLE (B002935)');
            			Ext.getCmp('hrTitle').setValue('SUPERVISORY MANAGER');
            			Ext.getCmp('businessRole').setValue('Not Yet Defined (9999)');
            			Ext.getCmp('phone').setValue('614/901-1403 ');
            			Ext.getCmp('email').setValue('JOSEPH.D.CABLE@CHASE.COM ');
            			Ext.getCmp('hrType').setValue('Employee ');
            			Ext.getCmp('hrStatus').setValue('Active ');
            			Ext.getCmp('mailCode').setValue('OH1-1208 ');
            			Ext.getCmp('streetAddress').setValue('1111 POLARIS PARKWAY , COLUMBUS, OH 432402050');
            			Ext.getCmp('lineOfBusiness').setValue('CPC (HR: CCB W/O CARD)');
            			Ext.getCmp('costCenter').setValue('135594');
            			Ext.getCmp('jobCode').setValue('PM0102');
            			Ext.getCmp('manager').setValue('KENNETH R BARHAUG (U043401)');
    					
    				}
    			}]
    		}]
        }];

        this.callParent(arguments);
    }
});