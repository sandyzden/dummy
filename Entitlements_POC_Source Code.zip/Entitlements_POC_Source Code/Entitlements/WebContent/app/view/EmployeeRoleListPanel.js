Ext.define('Entitlement.view.EmployeeRoleListPanel' ,{
    extend: 'Ext.panel.Panel',
    alias: 'widget.employeeRoleListPanel',
    title: 'Employee Role List',
    cls : 'panelHeader',
    collapsible : true,
    tools : [{
    	type : 'help'
    },{
    	type : 'maximize'
    }],
    initComponent: function() {

        this.items = [{
        	xtype : 'employeeRoleListGrid'
        }];

        this.callParent(arguments);
    }
});