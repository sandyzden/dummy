Ext.define('Entitlement.model.MyAccessProfileModel', {
    extend: 'Ext.data.Model',
    //fields: ['lob','bank', 'lastSignOn','status','action']
});