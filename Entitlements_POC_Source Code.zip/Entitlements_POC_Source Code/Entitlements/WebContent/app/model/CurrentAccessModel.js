Ext.define('Entitlement.model.CurrentAccessModel', {
    extend: 'Ext.data.Model',
    fields: ['lob','bank', 'entitlement','status','action']
});