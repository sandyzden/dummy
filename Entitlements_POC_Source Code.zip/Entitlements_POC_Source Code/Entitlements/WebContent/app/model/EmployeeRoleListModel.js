Ext.define('Entitlement.model.EmployeeRoleListModel', {
    extend: 'Ext.data.Model',
    fields: ['lob','bank', 'group','roleName','roleDescription','status','action']
});