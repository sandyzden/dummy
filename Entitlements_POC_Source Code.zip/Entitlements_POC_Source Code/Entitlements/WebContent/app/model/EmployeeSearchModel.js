Ext.define('Entitlement.model.EmployeeSearchModel', {
    extend: 'Ext.data.Model',
    fields: ['name','title', 'lob','manager','location']
});