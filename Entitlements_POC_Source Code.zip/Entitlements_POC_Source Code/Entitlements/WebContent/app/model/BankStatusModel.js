Ext.define('Entitlement.model.BankStatusModel', {
    extend: 'Ext.data.Model',
    fields: ['lob','bank', 'lastSignOn','status','action']
});