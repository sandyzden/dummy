Ext.define('Entitlement.model.SensitiveClientModel', {
    extend: 'Ext.data.Model',
    fields: ['bank','status','action']
});