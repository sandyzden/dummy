Ext.define('Entitlement.model.AccessProfileModel', {
    extend: 'Ext.data.Model',
    //fields: ['lob','bank', 'lastSignOn','status','action']
});