Ext.define('Entitlement.controller.AccessController', {
    extend: 'Ext.app.Controller',
    views : ['HomePanel','HeaderPanel','MainTabPanel','AccessSubTabPanel','EmployeeSearchPanel','EmployeeSearchGrid','EmployeeDisplayPanel','EmployeeDetailsForm',
             'BankStatusGrid','SensitiveClientGrid','EmployeeRoleListPanel','EmployeeRoleListGrid',
             'EmployeeOrganizationListPanel','EmployeeTeamListPanel','EmployeeTeamListGrid','EmployeeOrganizationListGrid','AccessProfileGrid','AccessProfilePanel',
             'CurrentAccessGrid','CurrentRolesGrid','CurrentWorkflowGrid','CurrentTeamsGrid','MyAccessProfileGrid','MyAccessProfilePanel','MyCurrentRolesGrid'],
    models : ['EmployeeSearchModel','BankStatusModel','SensitiveClientModel','EmployeeRoleListModel','EmployeeTeamListModel','EmployeeOrganizationListModel','AccessProfileModel','CurrentAccessModel','CurrentRolesModel','CurrentWorkflowModel','CurrentTeamsModel','MyAccessProfileModel','MyCurrentRolesModel'],
    stores: ['EmployeeSearchStore','BankStatusStore','SensitiveClientStore','EmployeeRoleListStore','EmployeeTeamListStore','EmployeeOrganizationListStore','AccessProfileStore','CurrentAccessStore','CurrentRolesStore','CurrentWorkflowStore','CurrentTeamsStore','MyAccessProfileStore','MyCurrentRolesStore'],
    init: function() {
        this.control({
        	'#ctg' : {
        		afterrender : this.renderAccessButton
        	},
        	'#crg' : {
        		afterrender : this.renderAccessButton1
        	},
        	'#addRole' : {
        		 click : this.showMyAccessCard
        	},
        	'#searchEmployee' : {
        		click : this.showCombo
        	}/*,
        	'#EmployeeSearchStore' : {
        		load : this.onSearch
        	}*/
        	
        });
    	
    },
   /* onSearch : function(){
    	
    	console.log('Inside');
    },*/
    showCombo:function(){
    	Ext.getCmp('employeeDetail2').enable();
    },
    
    renderAccessButton: function() {
    	Ext.getCmp('ctg').header.insert(1,{xtype : 'tbfill'});
		Ext.getCmp('ctg').header.insert(2,{xtype : 'button' , text : 'ADD MARKET / TEAM'});
		
    },
    renderAccessButton1: function() {
    	Ext.getCmp('crg').header.insert(1,{xtype : 'tbfill'});
		Ext.getCmp('crg').header.insert(2,{xtype : 'button' , text : 'ADD ANOTHER ROLE' , id : 'addRole'});
    },
    
    renderAccessCombo: function() {
    	alert(In);
    	//Ext.getCmp('employeeDetail2').selectText
    },
    
    showMyAccessCard : function(btn) {
    	Ext.getCmp('accessContainer').getLayout().setActiveItem(1);
    	
    	Ext.getCmp('lob').reset();
    	Ext.getCmp('bank').reset();
    	Ext.getCmp('group').reset();
    	Ext.getCmp('role').reset();
    	
    	
    	//Ext.getStore('LobStore').load();
    }
    
});

