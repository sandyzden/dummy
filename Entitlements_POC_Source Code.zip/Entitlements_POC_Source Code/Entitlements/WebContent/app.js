Ext.state.Manager.setProvider(new Ext.state.CookieProvider());

Ext.application({
    requires: ['Ext.container.Viewport'],
    name: 'Entitlement',
    controllers: ['AccessController'],
    views : ['HomePanel','HeaderPanel','MainTabPanel','AccessSubTabPanel'],
    appFolder: 'app',
    launch: function() {
        Ext.create('Ext.container.Viewport', {
             overflowY : 'auto',
            items: [
                {
                    xtype: 'homePanel'
                    //width :'100%'
                }
            ]
        });
    }
});