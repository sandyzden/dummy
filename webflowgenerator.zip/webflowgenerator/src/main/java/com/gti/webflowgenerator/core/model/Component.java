package com.gti.webflowgenerator.core.model;

import java.util.List;

public class Component {

    public List<IISWebSite> iisWebSites;
    public List<IISWebVDir> iisWebVdir;
    public List<IISWebAppool> iisWebAppools;

    public List<WinService> winServices;

    public List<WinService> getWinServices() {
        return winServices;
    }

    public void setWinServices(List<WinService> winServices) {
        this.winServices = winServices;
    }


    public List<IISWebSite> getIisWebSites() {
        return iisWebSites;
    }

    public void setIisWebSites(List<IISWebSite> iisWebSites) {
        this.iisWebSites = iisWebSites;
    }

    public List<IISWebVDir> getIisWebVdir() {
        return iisWebVdir;
    }

    public void setIisWebVdir(List<IISWebVDir> iisWebVdir) {
        this.iisWebVdir = iisWebVdir;
    }

    public List<IISWebAppool> getIisWebAppools() {
        return iisWebAppools;
    }

    public void setIisWebAppools(List<IISWebAppool> iisWebAppools) {
        this.iisWebAppools = iisWebAppools;
    }

}
