package com.gti.webflowgenerator.core.service;

import com.gti.webflowgenerator.core.model.Component;
import java.util.List;

public interface JSONSerializer {

    public List<Component> serializeJSON(String jsonArray);
}
