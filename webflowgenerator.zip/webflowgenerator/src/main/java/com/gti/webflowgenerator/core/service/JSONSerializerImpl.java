package com.gti.webflowgenerator.core.service;

import com.gti.webflowgenerator.core.model.Component;
import com.gti.webflowgenerator.core.model.*;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import org.json.*;

@Service
public class JSONSerializerImpl implements JSONSerializer {

    @Override
    public List<Component> serializeJSON(String stringJson) {
        return null;
    }

    public List<IISWebSite> createWebsite(Object webSiteObject) {
        List<IISWebSite> webSiteList = new ArrayList<>();
        try {
            if (webSiteObject instanceof JSONArray) {
                JSONArray webSiteArray = (JSONArray) webSiteObject;
                for (int i = 0; i < webSiteArray.length(); i++) {
                    JSONObject webSiteJsonObject = webSiteArray.getJSONObject(i);

                    IISWebSite webSite = new IISWebSite();
                    webSite.setWebSiteName(webSiteJsonObject.getString("websitename"));
                    webSite.setIdentity(webSiteJsonObject.getString("identity"));
                    webSite.setPhysicalPath(webSiteJsonObject.getString("physicalpath"));

                    webSiteList.add(webSite);
                }
            } else {
                JSONObject webSiteJsonObject = (JSONObject) webSiteObject;
                IISWebSite webSite = new IISWebSite();
                webSite.setWebSiteName(webSiteJsonObject.getString("websitename"));
                webSite.setIdentity(webSiteJsonObject.getString("identity"));
                webSite.setPhysicalPath(webSiteJsonObject.getString("physicalpath"));

                webSiteList.add(webSite);
            }
        }
        catch(Exception e) {
            System.out.println("[createWebsite] Error occured "+e.getMessage());
        }
        return webSiteList;
    }

    public List<IISWebAppool> createAppPool(Object appPoolObject ) {
        List<IISWebAppool> webPoolList = new ArrayList<>();
        try {
            if (appPoolObject instanceof JSONArray) {
                JSONArray appPoolArray = (JSONArray) appPoolObject;
                for (int i = 0; i < appPoolArray.length(); i++) {
                    JSONObject appPoolJsonObject = appPoolArray.getJSONObject(i);

                    IISWebAppool iisWebAppool = new IISWebAppool();
                    iisWebAppool.setAppPoolName(appPoolJsonObject.getString("appoolname"));
                    iisWebAppool.setIdentity(appPoolJsonObject.getString("identity"));
                    iisWebAppool.setNetVersion(appPoolJsonObject.getString("netruntime"));

                    webPoolList.add(iisWebAppool);
                }
            } else if( appPoolObject instanceof JSONObject ) {
                JSONObject appPoolJsonObject = (JSONObject) appPoolObject;

                IISWebAppool iisWebAppool = new IISWebAppool();
                iisWebAppool.setAppPoolName(appPoolJsonObject.getString("appoolname"));
                iisWebAppool.setIdentity(appPoolJsonObject.getString("identity"));
                iisWebAppool.setNetVersion(appPoolJsonObject.getString("netruntime"));

                webPoolList.add(iisWebAppool);

            }
        }
        catch(Exception e) {
            System.out.println("[createAppPool] Error occured "+e.getMessage());
        }
        return webPoolList;
    }

    public List<IISWebVDir> createVirtualDir(Object vdirObject) {
        List<IISWebVDir> webVDirList = new ArrayList<>();
        try {
            if(vdirObject instanceof JSONArray) {
                JSONArray vdirArray = (JSONArray) vdirObject;
                for(int i=0;i<vdirArray.length();i++) {
                    JSONObject vdirJsonObject = vdirArray.getJSONObject(i);

                    IISWebVDir iisWebVDir = new IISWebVDir();
                    iisWebVDir.setVirtualDirName(vdirJsonObject.getString("virtualdir"));
                    iisWebVDir.setPhysicalPath(vdirJsonObject.getString("physicalpath"));

                    webVDirList.add(iisWebVDir);
                }

            } else if(vdirObject instanceof  JSONObject ) {
                JSONObject vdirJsonObject = (JSONObject) vdirObject;

                IISWebVDir iisWebVDir = new IISWebVDir();
                iisWebVDir.setVirtualDirName(vdirJsonObject.getString("virtualdir"));
                iisWebVDir.setPhysicalPath(vdirJsonObject.getString("physicalpath"));

                webVDirList.add(iisWebVDir);
            }
        }
        catch (Exception e) {
            System.out.println("[createVirtualDir] Error occured "+e.getMessage());
        }
        return webVDirList;
    }

    public List<WinService> createWinService(Object winServiceObject) {
        List<WinService> winServiceList = new ArrayList<>();
        try {
            if(winServiceObject instanceof JSONArray) {
                JSONArray winServiceJArray = (JSONArray) winServiceObject;
                for(int i=0;i<winServiceJArray.length();i++) {
                    JSONObject vdirJsonObject = winServiceJArray.getJSONObject(i);

                    WinService winService = new WinService();
                    winService.setVirtualDirName(vdirJsonObject.getString("virtualdir"));
                    iisWebVDir.setPhysicalPath(vdirJsonObject.getString("physicalpath"));

                    webVDirList.add(iisWebVDir);
                }

            } else if(vdirObject instanceof  JSONObject ) {
                JSONObject vdirJsonObject = (JSONObject) vdirObject;

                IISWebVDir iisWebVDir = new IISWebVDir();
                iisWebVDir.setVirtualDirName(vdirJsonObject.getString("virtualdir"));
                iisWebVDir.setPhysicalPath(vdirJsonObject.getString("physicalpath"));

                webVDirList.add(iisWebVDir);
            }
        }
        catch (Exception e) {
            System.out.println("[createVirtualDir] Error occured "+e.getMessage());
        }
        return webVDirList;
    }

    public boolean ifElementExist(JSONObject jsonObject) {

    }
}
