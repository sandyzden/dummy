package com.gti.webflowgenerator.core.model;

public class IISWebAppool {

    public String appPoolName;
    public String identity;
    public String netVersion;

    public String getAppPoolName() {
        return appPoolName;
    }

    public void setAppPoolName(String appPoolName) {
        this.appPoolName = appPoolName;
    }

    public String getIdentity() {
        return identity;
    }

    public void setIdentity(String identity) {
        this.identity = identity;
    }

    public String getNetVersion() {
        return netVersion;
    }

    public void setNetVersion(String netVersion) {
        this.netVersion = netVersion;
    }

}
