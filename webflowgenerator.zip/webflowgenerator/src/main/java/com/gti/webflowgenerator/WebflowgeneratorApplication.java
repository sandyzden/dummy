package com.gti.webflowgenerator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebflowgeneratorApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebflowgeneratorApplication.class, args);
	}
}
