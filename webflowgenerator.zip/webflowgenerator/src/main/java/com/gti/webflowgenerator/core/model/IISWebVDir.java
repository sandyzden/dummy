package com.gti.webflowgenerator.core.model;

public class IISWebVDir {

    public String virtualDirName;
    public String physicalPath;
    public String identity;

    public String getVirtualDirName() {
        return virtualDirName;
    }

    public void setVirtualDirName(String virtualDirName) {
        this.virtualDirName = virtualDirName;
    }

    public String getPhysicalPath() {
        return physicalPath;
    }

    public void setPhysicalPath(String physicalPath) {
        this.physicalPath = physicalPath;
    }

    public String getIdentity() {
        return identity;
    }

    public void setIdentity(String identity) {
        this.identity = identity;
    }

}
