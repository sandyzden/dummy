package com.gti.webflowgenerator.core.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;

import com.gti.webflowgenerator.core.model.Component;
import com.gti.webflowgenerator.core.service.JSONSerializer;

@RestController
public class ParserController {

    @Autowired
    JSONSerializer jsonSerializer;

    @RequestMapping(value="/generate", method = RequestMethod.POST)
    public String generateWorkflow(HttpEntity<String> httpEntity)
    {
       //System.out.println("Request Body "+ httpEntity.getBody().toString());
       jsonSerializer.serializeJSON(httpEntity.getBody().toString());
        return "Hello World";
    }

}
