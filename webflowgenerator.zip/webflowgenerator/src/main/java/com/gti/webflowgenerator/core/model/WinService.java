package com.gti.webflowgenerator.core.model;

public class WinService {

    public String serviceName;
    public String identity;
    public String physicalpath;
    public String startype;


    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public String getIdentity() {
        return identity;
    }

    public void setIdentity(String identity) {
        this.identity = identity;
    }

    public String getPhysicalpath() {
        return physicalpath;
    }

    public void setPhysicalpath(String physicalpath) {
        this.physicalpath = physicalpath;
    }

    public String getStartype() {
        return startype;
    }

    public void setStartype(String startype) {
        this.startype = startype;
    }

}


