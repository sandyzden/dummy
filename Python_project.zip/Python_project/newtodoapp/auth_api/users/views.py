# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from models import User
from rest_framework import generics
from rest_framework.response import Response
from rest_framework.reverse import reverse

from serializers import UserSerializer


# Create your views here.

class UserList(generics.ListCreateAPIView):
    queryset = User.objects.all()
    serializer_class = UserSerializer


class UserDetail(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = UserSerializer

    def get_queryset(self):
        return User.objects.all().filter(username=self.request.user)
