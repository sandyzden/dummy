Ext.define('Entitlement.view.EmployeeClientCoverageListPanel' ,{
    extend: 'Ext.panel.Panel',
    alias: 'widget.employeeClientCoverageListPanel',
    title: 'Employee Client Coverage List',
    cls : 'panelHeader',
    tools : [{
    	type : 'help'
    },{
    	type : 'minimize'
    },{
    	type : 'maximize'
    }],
    initComponent: function() {

        this.items = [];

        this.callParent(arguments);
    }
});