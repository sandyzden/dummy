Ext.define('Entitlement.view.CurrentTeamsGrid' ,{
    extend: 'Ext.form.FormPanel',
    alias: 'widget.currentTeamsGrid',
    cls : 'gridHeader',
    title: 'Current Clients Markets/Teams:',
    buttons: [{ 
 	   text: 'CANCEL',
 	   tooltip: 'calcel',
 	   handler: function() {
 	     // console.log('TODO: cancel');
 		  Ext.getCmp('pnlEmployeeHome').getLayout().setActiveItem(0);
 	   }
    },{
        text: 'RESET',
        name: 'btnReset',
        handler: function () {
          formPanel.getForm().reset();
      }
    
  }],
  //Ext.getCmp('ctg').header.insert(1,{xtype : 'tbfill'});
  //Ext.getCmp('ctg').header.insert(2,{xtype : 'button' , text : 'Test'});

    //store : 'CurrentTeamsStore',  
   // columnLines : true,
  /*  initComponent: function() {



        this.callParent(arguments);
    }*/
});