Ext.define('Entitlement.view.CurrentWorkflowGrid' ,{
    extend: 'Ext.grid.Panel',
    alias: 'widget.currentWorkflowGrid',
    cls : 'gridHeader',
    title: 'Current Workflow Teams:',
    store : 'CurrentWorkflowStore',  
    columnLines : true,
    overflowY: 'auto',
	maxHeight: 200,
    initComponent: function() {

        this.columns = [
            {header: 'Bank',  dataIndex: 'bank',  flex: 1},
            {header: 'Role', dataIndex: 'role', flex: 1},
            {header: 'Workflow Team', dataIndex: 'workflow', flex: 1},
            {header: 'Status',  dataIndex: 'status',  flex: 1},
            {header: 'Action', dataIndex: 'action', flex: 1}
        ];

        this.callParent(arguments);
    }
});