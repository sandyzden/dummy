Ext.define('Entitlement.view.HeaderPanel' ,{
    extend: 'Ext.panel.Panel',
    alias: 'widget.headerPanel',
    layout: {
        type: 'hbox'
    },
    defaults : {
    	margin : '10 10 10 10'
    },
    initComponent: function() {

        this.items = [{
        	xtype : 'label',
        	cls : 'headerTxtCls',
        	text : 'API Store'
        },{
        	xtype: 'tbfill'
        },{
        	xtype : 'label',
        	cls : 'headerTxtCls',
        	text : 'JPMorgan Chase & Co.',
        	margin : '10 20 10 10',
        
        }];

        this.callParent(arguments);
    }
});