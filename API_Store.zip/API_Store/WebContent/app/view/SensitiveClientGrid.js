Ext.define('Entitlement.view.SensitiveClientGrid' ,{
    extend: 'Ext.grid.Panel',
    alias: 'widget.sensitiveClientGrid',
    cls : 'gridHeader',
    title: 'Sensitive Client',
    store : 'SensitiveClientStore',  
    columnLines : true,
    initComponent: function() {

        this.columns = [
            {header: 'Bank',  dataIndex: 'bank',  flex: 5},
            {header: 'Status',  dataIndex: 'status',  flex: 1},
            {header: 'Action', dataIndex: 'action', flex: 1}
        ];

        this.callParent(arguments);
    }
});