Ext.define('Entitlement.view.MyCurrentRolesGrid' ,{
    extend: 'Ext.grid.Panel',
    alias: 'widget.myCurrentRolesGrid',
    cls : 'gridHeader',
    title: 'Current Roles:',
    store : 'MyCurrentRolesStore',  
    columnLines : true, 
    overflowY: 'auto',
	maxHeight: 200,
    initComponent: function() {

        this.columns = [
            {header: 'Bank', dataIndex: 'bank', flex: 1},
            {header: 'Group', dataIndex: 'group', flex: 1},
            {header: 'Role', dataIndex: 'role', flex: 2},
            {header: 'Status',  dataIndex: 'status',  flex: 1},
            {header: 'Action', dataIndex: 'action', flex: 1}
        ];
        
        this.on({
        	scope: this,
        	afterrender: function(grid){
        		grid.store.load({
        			callback: function(records, options, success){
        				if(success){
        					//data processing, if required
        				}
        				else{
        					//alert('Server Error');
        					//handle the service failure
        				}
        			}
        		});
        	}
        	
        })
        
        this.dockedItems = [{
        	xtype: 'pagingtoolbar',
            store: 'MyCurrentRolesStore',  
            dock: 'bottom',
            displayInfo: false
        }];

        this.callParent(arguments);
    }
});