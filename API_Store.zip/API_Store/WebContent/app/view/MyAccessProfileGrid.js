var states = Ext.create('Ext.data.Store', {
    fields: ['abbr', 'LOB'],
    data : [
        {"abbr":"AL", "LOB":"Chase Private Client"},
        {"abbr":"AK", "LOB":"International Private Bank"},
        {"abbr":"AZ", "LOB":"JP Morgan Securities"},
        {"abbr":"AM", "LOB":"Legacy Roles"},
        {"abbr":"AN", "LOB":"Private Bank"},
        {"abbr":"AO", "LOB":"Private Client Services"},
        {"abbr":"AT", "LOB":"Shared Services"},
        {"abbr":"AC", "LOB":"Treasury & Securities Services"},
        //...
    ]
});

var state = Ext.create('Ext.data.Store', {
    fields: ['abbr', 'banks'],
    data : [
        {"abbr":"AS", "banks":"Wealth Mgmt"},
 
    ]
});

var stateg = Ext.create('Ext.data.Store', {
    fields: ['abbr', 'group'],
    data : [
        {"abbr":"AL", "group":"Banker / Advisor"},
        {"abbr":"AK", "group":"Client Service"},
        {"abbr":"AZ", "group":"Investments"},
        {"abbr":"AM", "group":"Operations"},
        {"abbr":"AN", "group":"Risk / Audit / Compliance "},
        {"abbr":"AO", "group":"Visibility"},
      
        //...
    ]
});

var stateh = Ext.create('Ext.data.Store', {
    fields: ['abbr', 'role'],
    data : [
        {"abbr":"AL", "role":"CPC Advisor"},
        {"abbr":"AK", "role":"CPC Advisor Assistant"},
        
      
        //...
    ]
});

/*var tr = CurrentRolesGrid.getView().getNode('crg');
Ext.each(tr.childNodes, function(td) {
  td.style.backgroundColor = '#FFFFCC';
  });*/

Ext.define('Entitlement.view.MyAccessProfileGrid' ,{
    extend: 'Ext.form.FormPanel',
    alias: 'widget.myAccessProfileGrid',
    id: 'formpanel',
    cls : 'gridHeader',
    title: 'Add a Role for ',
    layout: 'hbox',
 
    items: [{
    	xtype : 'tbfill'
    	
    },{
    	xtype : 'label',
    	text : 'Add a Role:',
    	cls : 'alignLabel'
    	//width : 700,
    },{
        xtype: 'combo',
        flex: 0.3,
        allowBlank: false,
        //autoShow: false,
        fieldLabel: 'LOB',
        id : 'lob',
        store: states,
        emptyText : 'Select a LOB',
        labelAlign  : 'top',
        displayField : 'LOB',
        valueField: 'abbr'
      /*  labelWidth : 150,
        width : '30%',
        margin : '0 10 0 0'*/
       }, {
        xtype: 'splitter'
    }, {
        xtype: 'combo',
        flex: 0.3,
        allowBlank: false,
        fieldLabel: 'Bank',
        store: state,
        id : 'bank',
        emptyText : 'Select a Bank',
        labelAlign  : 'top',
        displayField : 'banks',
        valueField: 'banks'
        //labelWidth: 200
        //width : 180
        
    }, {
        xtype: 'splitter'
    }, {
        xtype: 'combo',
        flex: 0.3,
        allowBlank: false,
        fieldLabel: 'Select a Group',
        store: stateg,
        id : 'group',
        emptyText : 'Select a Group',
        labelAlign  : 'top',
        displayField : 'group',
        valueField: 'group'
        	
        //width : 180
    },{
        xtype: 'splitter'
    }, {
    	xtype:'combo',
    	flex:0.3,
        id : 'role',
        allowBlank: false,
    	 fieldLabel: 'Select a Role',
    	 store: stateh,
    	 emptyText : 'Select a Role',
    	 labelAlign  : 'top',
    	   displayField : 'role',
           valueField: 'role'
    	 //labelWidth: 50
    	// width : 180
    }],
    
    dockedItems: [
                  {
        xtype:'toolbar',
    	dock:'bottom',
    	items:['->', {
    	
      	  xtype: 'displayfield',
          id: 'dspErrorMsg',
          //dock: 'bottom'
        
    	 },
      {
    		 xtype:'button',
    		 text: 'CANCEL',
    		   tooltip: 'cancel',
    		   //dock:'bottom',
    		   maxWidth:100,
    		   handler: function() {
    			   Ext.getCmp('accessContainer').getLayout().setActiveItem(0);
    		   }
    		 
      },{
    	  xtype:'button',
    	  text: 'SAVE AND CONTINUE',
    	     name: 'btnReset',
    	     dock:'bottom',
    	     maxWidth:150,
    	     id:'btn',
                 
                  
                  

 
   
 /*   buttons: [
              
              
		{ 
    	text: 'CANCEL',
	   tooltip: 'cancel',
	   handler: function() {
		   Ext.getCmp('accessContainer').getLayout().setActiveItem(0);
	   }
    },{
    
     text: 'SAVE AND CONTINUE',
     name: 'btnReset',
     id:'btnId',*/
     handler: function () {
    	 
    	
    	 
    	 
    	 /*var myCurrentRolesGrid = Ext.getCmp('myCurrentRolesGrid');
    	
    	 var record = myCurrentRolesGrid.store.add ({
    		 bank: Ext.getCmp('bank').getValue(),
    		 group: Ext.getCmp('group').getValue(),
    		 role : Ext.getCmp('role').getValue(),
    		 status : '',
    		 action : ''
    		
    	    });*/
    	 
    	/* if(Ext.getCmp('formpanel').getForm().isValid( )){
    		//Ext.Msg.alert('error');
    		 var myCurrentRolesGrid = Ext.getCmp('myCurrentRolesGrid');
  	    	
        	 var record = myCurrentRolesGrid.store.add ({
        		 bank: Ext.getCmp('bank').getValue(),
        		 group: Ext.getCmp('group').getValue(),
        		 role : Ext.getCmp('role').getValue(),
        		 status : '',
        		 action : ''
        		
        	    }); 
        	 var tr = myCurrentRolesGrid.getView().getNode(record[0]);
        	 Ext.each(tr.childNodes, function(td) {
          	   td.style.backgroundColor = '#FFFFCC';
          	   });
    		 
    	 }
    	 else{
    		 //Ext.Msg.alert('error');
    	 }
*/    	
    	/* if(Ext.getCmp('formpanel').getForm().isValid( )){
    		 Ext.Msg.alert('error');
    	 }*/
    	 
    if( Ext.getCmp('bank').getValue()==null & Ext.getCmp('group').getValue()==null & Ext.getCmp('role').getValue()==null & Ext.getCmp('lob').getValue()==null ){
    		 //Ext.Msg.alert('error');
    		 Ext.getCmp('dspErrorMsg').setValue("Please select from LOB,Bank,Group and Role to add");
    	 }else{
    		 var myCurrentRolesGrid = Ext.getCmp('myCurrentRolesGrid');
    	    	
        	 var record = myCurrentRolesGrid.store.add ({
        		 bank: Ext.getCmp('bank').getValue(),
        		 group: Ext.getCmp('group').getValue(),
        		 role : Ext.getCmp('role').getValue(),
        		 status : '',
        		 action : ''
        		
        	    }); 
        	 var tr = myCurrentRolesGrid.getView().getNode(record[0]);
        	 Ext.each(tr.childNodes, function(td) {
          	   td.style.backgroundColor = '#FFFFCC';
          	   });
    	 }
    	 
    	 //var myCurrentRolesGrid = Ext.getCmp('myCurrentRolesGrid');
    	 var tr = myCurrentRolesGrid.getView().getNode(record[0]);
    	 Ext.each(tr.childNodes, function(td) {
      	   td.style.backgroundColor = '#FFFFCC';
      	   });
    	 if(  Ext.getCmp('group').getValue()==null & Ext.getCmp('role').getValue()==null & Ext.getCmp('lob').getValue()==null){
    		// Ext.Msg.alert('error');
    		 Ext.getCmp('dspErrorMsg').setValue("Please select from LOB,Bank,Group and Role to add ");
    	 }else{
    		 
    		 var crg = Ext.getCmp('crg');
    	    	
        	 //Ext.getCmp('crg').store.add ({
        	 var records=crg.store.add({
        		 lob: Ext.getCmp('lob').getValue(),
        		 bank: Ext.getCmp('bank').getValue(),
        		 group: Ext.getCmp('group').getValue(),
        		 role : Ext.getCmp('role').getValue(),
        		 status : '',
        		 action : ''
        	 });
        	 var tr1 = crg.getView().getNode(records[0]);
        	 Ext.each(tr1.childNodes, function(td) {
          	   td.style.backgroundColor = '#FFFFCC';
          	   });
    	 }
    	 
    	/* var crg = Ext.getCmp('crg');
    	
    	 //Ext.getCmp('crg').store.add ({
    	 var records=crg.store.add({
    		 lob: Ext.getCmp('lob').getValue(),
    		 bank: Ext.getCmp('bank').getValue(),
    		 group: Ext.getCmp('group').getValue(),
    		 role : Ext.getCmp('role').getValue(),
    		 status : '',
    		 action : ''
    	 });
    	 var tr1 = crg.getView().getNode(records[0]);
    	 Ext.each(tr1.childNodes, function(td) {
      	   td.style.backgroundColor = '#FFFFCC';
      	   });*/
    	 
    	 Ext.getCmp('accessContainer').getLayout().setActiveItem(0);
    	
    	 
   }
      }],
 
}],
});