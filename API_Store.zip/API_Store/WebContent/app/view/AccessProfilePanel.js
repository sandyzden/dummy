Ext.define('Entitlement.view.AccessProfilePanel' ,{
    extend: 'Ext.panel.Panel',
    alias: 'widget.accessProfilePanel',
    title: 'My Access Profile',
    cls : 'panelHeader',
    collapsible : true,
    
    initComponent: function() {

        this.items = [{
        	xtype : 'accessProfileGrid',
        	
        	id: 'accessProfileGrid'
        },{
        	xtype : 'currentAccessGrid'
        },{
        	xtype : 'currentRolesGrid',
        	id:'crg'
        },{
        	xtype: 'currentWorkflowGrid'
        },
        {
        	xtype : 'currentTeamsGrid',
        	id:'ctg'
        }];
        
      
        this.callParent(arguments);
    }
});