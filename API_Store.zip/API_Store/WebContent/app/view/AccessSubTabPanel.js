 Ext.define('Entitlement.view.AccessSubTabPanel' ,{
    extend: 'Ext.tab.Panel',
    alias: 'widget.accessSubTabPanel',
    layout : 'card',
    border : false,
    frame : false,
    initComponent: function() {
    	this.items = [{
    		title : 'DashBoard',
    		id : 'pnlEmployeeHome',
    		/*layout : 'card',
    		items:[{
    		    	   xtype:'container',
    		    	   id: 'contPage1',
    		    	   items : [{   
    		    		   	xtype : 'employeeSearchPanel',
    		    		   	margin : '20 0 0 0'
    		    	   			},{
    		    	   		xtype : 'employeeDisplayPanel',
    		    	   		margin : '20 0 0 0'
    		    	   			},{
    		    	   		xtype : 'employeeRoleListPanel',
    		    	   		margin : '20 0 0 0'
    		    	   			},{
    		    	   		xtype : 'employeeTeamListPanel',
    		    	   		margin : '20 0 0 0'
    		    	   			},{
    		    	   		xtype : 'employeeOrganizationListPanel',
    		    	   		margin : '20 0 0 0'
    		    	   			}],
    		},{
                xtype : 'container',
                id : 'accessContainer',
                layout:'card',
                items : [{
                	xtype : 'accessProfilePanel',
                	margin : '20 0 0 0'
                },{
                	xtype: 'myAccessProfilePanel',
	    			margin : '20 0 0 0'
                }]
    		}]*/
    		
    		
    		
    		/*items :[{
    			xtype : 'container',
    			id :'accessContainer',
    			layout : 'card',
    			items : [{
    	    			xtype : 'accessProfilePanel',
    	    			//xtype: 'myAccessProfilePanel',
    	    			margin : '20 0 0 0'
    			},{
    				//xtype : 'accessProfilePanel',
	    			xtype: 'myAccessProfilePanel',
	    			margin : '20 0 0 0'
    		
    		}]
    		}] */
    			   			
    		
    	},{
    		title : 'Projects'
    	},    	{
    		title : 'Component'
    	},{
    		title : 'Entity'
    	},{
    		title : 'URL Mapping'
    	}];

        this.callParent(arguments);
    }
});