Ext.define('Entitlement.view.EmployeeTeamListGrid' ,{
    extend: 'Ext.grid.Panel',
    alias: 'widget.employeeTeamListGrid',
    cls : 'gridHeader',
    title: 'Teams: (to view Team, click the name)',
    store : 'EmployeeTeamListStore', 
    columnLines : true,
    initComponent: function() {

        this.columns = [
            {header: 'Bank',  dataIndex: 'bank',  flex: 1},
            {header: 'Role',  dataIndex: 'role',  flex: 1},
            {header: 'Team',  dataIndex: 'team',  flex: 1},
            {header: 'Team Description',  dataIndex: 'teamDescription',  flex: 2},
            {header: 'Status',  dataIndex: 'status',  flex: 1},
            {header: 'Action', dataIndex: 'action', flex: 1}
        ];

        this.callParent(arguments);
    }
});