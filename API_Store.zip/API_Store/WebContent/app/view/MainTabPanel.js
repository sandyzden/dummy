Ext.define('Entitlement.view.MainTabPanel' ,{
    extend: 'Ext.tab.Panel',
    alias: 'widget.mainTabPanel',
    layout : 'card',
    border : false,
    frame : false,
    initComponent: function() {
    	this.items = [{
    		title : 'Profile',
    		items : [{
    			xtype : 'accessSubTabPanel',
    			id : 'accessSubTabPnl'
    		}]
    	}];

        this.callParent(arguments);
    }
});