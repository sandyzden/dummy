Ext.define('Entitlement.view.EmployeeRoleListGrid' ,{
    extend: 'Ext.grid.Panel',
    alias: 'widget.employeeRoleListGrid',
    cls : 'gridHeader',
    title: 'Roles: (to view Role, click the name)',
    store : 'EmployeeRoleListStore',  
    columnLines : true,
    overflowY: 'auto',
	maxHeight: 200,
    initComponent: function() {

        this.columns = [
            {header: 'LOB', dataIndex: 'lob', flex: 0.5},
            {header: 'Bank',  dataIndex: 'bank',  flex: 0.5},
            {header: 'Group',  dataIndex: 'group',  flex: 0.5},
            {header: 'Role Name',  dataIndex: 'roleName',  flex: 0.5},
            {header: 'Role Description',  dataIndex: 'roleDescription',  flex: 3},
            {header: 'Status',  dataIndex: 'status',  flex: 1},
            {header: 'Action', dataIndex: 'action', flex: 1}
        ];

        this.callParent(arguments);
    }
});