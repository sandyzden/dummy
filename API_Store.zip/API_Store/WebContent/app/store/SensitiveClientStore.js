Ext.define('Entitlement.store.SensitiveClientStore', {
    extend: 'Ext.data.Store',
    model: 'Entitlement.model.SensitiveClientModel',
    autoLoad : false,
    sorters : {
    	property : 'bank',
    	direction : 'ASC'
    },
    proxy: {
		type: 'ajax',
		reader: {
			type: 'json',
			root: 'data'
		},
		url: 'data/sensitive.json'
	} 
});