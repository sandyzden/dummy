Ext.define('Entitlement.store.EmployeeTeamListStore', {
    extend: 'Ext.data.Store',
    model: 'Entitlement.model.EmployeeTeamListModel',
    autoLoad : false,
    sorters : {
    	property : 'bank',
    	direction : 'ASC'
    },
    proxy: {
		type: 'ajax',
		reader: {
			type: 'json',
			root: 'data'
		},
		url: 'rest/UserInfoService/user'
	} 
});