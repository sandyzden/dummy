Ext.define('Entitlement.store.EmployeeOrganizationListStore', {
    extend: 'Ext.data.Store',
    model: 'Entitlement.model.EmployeeOrganizationListModel',
    autoLoad : false,
    sorters : {
    	property : 'bank',
    	direction : 'ASC'
    },
    proxy: {
		type: 'ajax',
		reader: {
			type: 'json',
			root: 'data'
		},
		url: 'rest/UserInfoService/user'
	} 
});