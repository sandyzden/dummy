Ext.define('Entitlement.store.MyAccessProfileStore', {
    extend: 'Ext.data.Store',
    model: 'Entitlement.model.MyAccessProfileModel',
    autoLoad : false,
  /*  sorters : {
    	property : 'lob',
    	direction : 'ASC'
    },
    proxy: {
		type: 'ajax',
		reader: {
			type: 'json',
			root: 'data'
		},
		url: 'data/bankStatus.json'
	} */
 
});