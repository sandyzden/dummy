//var itemsPerPage = 2; 
Ext.define('Entitlement.store.MyCurrentRolesStore', {
    extend: 'Ext.data.Store',
    model: 'Entitlement.model.MyCurrentRolesModel',
    //pageSize: itemsPerPage,
    autoLoad : false,
    sorters : {
    	property : 'bank',
    	direction : 'ASC'
    },
    proxy: {
		type: 'ajax',
		reader: {
			type: 'json',
			root: 'data'
		},
		url: 'rest/UserInfoService/user'//'data/bankStatus.json'
	} 
});
/*store.load({
    params:{
        start:0,
        limit: itemsPerPage
    }
});*/