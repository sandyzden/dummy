Ext.define('Entitlement.store.BankStatusStore', {
    extend: 'Ext.data.Store',
    model: 'Entitlement.model.BankStatusModel',
    autoLoad : false,
    sorters : {
    	property : 'lob',
    	direction : 'ASC'
    },
    proxy: {
		type: 'ajax',
		reader: {
			type: 'json',
			root: 'data'
		},
		url: 'data/bankStatus.json'
	} 
});