Ext.define('Entitlement.model.CurrentTeamsModel', {
    extend: 'Ext.data.Model',
    //fields: ['lob','bank', 'group','role','status','action']
});