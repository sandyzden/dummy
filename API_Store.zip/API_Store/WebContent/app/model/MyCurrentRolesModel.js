Ext.define('Entitlement.model.MyCurrentRolesModel', {
    extend: 'Ext.data.Model',
    fields: ['bank', 'group','role','status','action']
});