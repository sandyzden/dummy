Ext.define('Entitlement.model.EmployeeTeamListModel', {
    extend: 'Ext.data.Model',
    fields: ['bank','role', 'team','teamDescription','status','action']
});