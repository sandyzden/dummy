Ext.define('Entitlement.model.CurrentWorkflowModel', {
    extend: 'Ext.data.Model',
    fields: ['bank','role', 'workflow','status','action']
});