Ext.define('Entitlement.model.EmployeeOrganizationListModel', {
    extend: 'Ext.data.Model',
    fields: ['bank','path', 'orgTeam','type','name','status','action']
});