Ext.define('Entitlement.model.CurrentRolesModel', {
    extend: 'Ext.data.Model',
    fields: ['lob','bank', 'group','role','status','action']
});