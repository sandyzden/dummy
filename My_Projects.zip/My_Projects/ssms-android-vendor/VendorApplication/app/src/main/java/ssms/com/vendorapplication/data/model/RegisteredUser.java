package ssms.com.vendorapplication.data.model;

/**
 * Created by sendilkumar on 12/02/17.
 */

public class RegisteredUser {

    public String userId;
    public String id;
    public String title;
    public String body;

    public RegisteredUser() {
    }

    public RegisteredUser(String userId, String id, String title, String body)
    {
        this.userId = userId;
        this.id = id;
        this.title = title;
        this.body = body;
    }
}
