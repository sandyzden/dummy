package ssms.com.vendorapplication.data;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Singleton;

import rx.Observable;
import rx.functions.Func1;
import ssms.com.vendorapplication.data.local.DatabaseHelper;
import ssms.com.vendorapplication.data.local.PreferencesHelper;
import ssms.com.vendorapplication.data.model.RegisteredUser;
import ssms.com.vendorapplication.data.remote.UserService;

@Singleton
public class DataManager {

    private final UserService mUserService;
    private final DatabaseHelper mDatabaseHelper;
    private final PreferencesHelper mPreferencesHelper;

    @Inject
    public DataManager(UserService userService, PreferencesHelper preferencesHelper,
                       DatabaseHelper databaseHelper) {
        mUserService = userService;
        mPreferencesHelper = preferencesHelper;
        mDatabaseHelper = databaseHelper;
    }

    public PreferencesHelper getPreferencesHelper() {
        return mPreferencesHelper;
    }

    public Observable<List<RegisteredUser>> getUsers() {
        //String auth = RibotService.Util.buildAuthorization(mPreferencesHelper.getAccessToken());
        return mUserService.getRegisteredUsers();
    }
}
