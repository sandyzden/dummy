package ssms.com.vendorapplication.data.local;

import android.content.ContentValues;
import android.database.Cursor;

import java.util.Date;

import ssms.com.vendorapplication.data.model.RegisteredUser;

public class Db {

    public Db() { }

    public abstract static class UserProfileTable {
        public static final String TABLE_NAME = "user_profile";

        public static final String COLUMN_USERID = "userId";
        public static final String COLUMN_ID = "id";
        public static final String COLUMN_TITLE = "title";
        public static final String COLUMN_BODY = "body";


        public static final String CREATE =
                "CREATE TABLE " + TABLE_NAME + " (" +
                        COLUMN_USERID + " TEXT PRIMARY KEY, " +
                        COLUMN_ID + " TEXT NOT NULL, " +
                        COLUMN_TITLE + " TEXT,"+
                        COLUMN_BODY + "TEXT" +

                " ); ";

        public static ContentValues toContentValues(RegisteredUser user) {
            ContentValues values = new ContentValues();
            values.put(COLUMN_USERID, user.userId);
            values.put(COLUMN_ID, user.id);
            values.put(COLUMN_TITLE, user.title);
            values.put(COLUMN_BODY,user.body);
            return values;
        }

        public static RegisteredUser parseCursor(Cursor cursor) {
            RegisteredUser user = new RegisteredUser();
            user.userId = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_USERID));
            user.id = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ID));
            user.title = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TITLE));
            user.body = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_BODY));
            return user;
        }


    }
}
