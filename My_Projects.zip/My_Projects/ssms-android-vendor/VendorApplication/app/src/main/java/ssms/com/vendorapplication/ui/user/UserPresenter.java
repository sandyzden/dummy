package ssms.com.vendorapplication.ui.user;


import java.util.Collections;
import java.util.List;

import javax.inject.Inject;

import ssms.com.vendorapplication.data.DataManager;
import ssms.com.vendorapplication.data.model.RegisteredUser;
import ssms.com.vendorapplication.ui.base.Presenter;
import rx.Observable;
import rx.Subscriber;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;
import timber.log.Timber;

public class UserPresenter implements Presenter<UserMvpView> {

    private final DataManager mDataManager;
    public Subscription mSubscription;
    private UserMvpView mMvpView;
    private List<RegisteredUser> mCachedUsers;

    @Inject
    public UserPresenter(DataManager dataManager) {
        mDataManager = dataManager;
    }

    @Override
    public void attachView(UserMvpView mvpView) {
        mMvpView = mvpView;
    }

    @Override
    public void detachView() {
        mMvpView = null;
        if (mSubscription != null) mSubscription.unsubscribe();
    }

    public void loadUsers() {
        loadUsers(false);
    }

    /**
     * Load the list of Ribots
     * @param allowMemoryCacheVersion if true a cached version will be returned from memory,
     *                                unless nothing is cached yet. Use false if you want an up
     *                                to date version of the ribots.
     */
    public void loadUsers(boolean allowMemoryCacheVersion) {
        mMvpView.showUsersProgress(true);
        if (mSubscription != null) mSubscription.unsubscribe();
        mSubscription = getUsersObservable(allowMemoryCacheVersion)
                .subscribe(new Subscriber<List<RegisteredUser>>() {
                    @Override
                    public void onCompleted() {
                        mMvpView.showUsersProgress(false);
                    }

                    @Override
                    public void onError(Throwable e) {
                        Timber.e("There was an error retrieving the Users " + e);
                        mMvpView.showUsersProgress(false);
                        mMvpView.showUsersError();
                    }

                    @Override
                    public void onNext(List<RegisteredUser> users) {
                        mCachedUsers = users;
                        if (!users.isEmpty()) {
                            //Collections.sort(users);
                            mMvpView.showUsers(users);
                        } else {
                            mMvpView.showEmptyMessage();
                        }
                    }
                });
    }

    private Observable<List<RegisteredUser>> getUsersObservable(boolean allowMemoryCacheVersion) {
        if (allowMemoryCacheVersion && mCachedUsers != null) {
            return Observable.just(mCachedUsers);
        } else {
            return mDataManager.getUsers()
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribeOn(Schedulers.io());
        }
    }
}
