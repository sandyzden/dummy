package ssms.com.vendorapplication.ui;

import android.content.Intent;
import android.os.Bundle;

import javax.inject.Inject;

import ssms.com.vendorapplication.data.DataManager;
import ssms.com.vendorapplication.ui.base.BaseActivity;
import ssms.com.vendorapplication.ui.main.MainActivity;

public class LauncherActivity extends BaseActivity {

    @Inject DataManager mDataManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityComponent().inject(this);
        Intent intent;
        /*if (mDataManager.getPreferencesHelper().getAccessToken() != null) {
            intent = MainActivity.getStartIntent(this, false);
        } else {
            intent = SignInActivity.getStartIntent(this, false);
        }*/
        intent = MainActivity.getStartIntent(this,false);
        startActivity(intent);
    }

    @Override
    protected void onPostResume() {
        super.onPostResume();
        finish();
    }
}
