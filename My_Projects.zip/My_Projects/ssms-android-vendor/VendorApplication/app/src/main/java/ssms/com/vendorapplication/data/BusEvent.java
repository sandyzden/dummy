package ssms.com.vendorapplication.data;

public class BusEvent {

    public static class AuthenticationError { }
}
