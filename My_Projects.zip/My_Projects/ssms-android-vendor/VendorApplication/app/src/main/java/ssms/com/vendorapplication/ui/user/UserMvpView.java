package ssms.com.vendorapplication.ui.user;

import java.util.List;

import ssms.com.vendorapplication.data.model.RegisteredUser;
import ssms.com.vendorapplication.ui.base.MvpView;

public interface UserMvpView extends MvpView {

    void showUsers(List<RegisteredUser> ribots);

    void showUsersProgress(boolean show);

    void showEmptyMessage();

    void showUsersError();
}
