package ssms.com.vendorapplication.ui.user;

import android.app.Fragment;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.List;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import ssms.com.vendorapplication.R;
import ssms.com.vendorapplication.data.model.RegisteredUser;
import ssms.com.vendorapplication.ui.base.BaseActivity;
import ssms.com.vendorapplication.util.DialogFactory;
import ssms.com.vendorapplication.ui.adapter.UserAdapter;

public class UserFragment extends Fragment implements UserMvpView {

    @Inject UserPresenter mUserPresenter;
    @Inject UserAdapter mUserAdapter;

    @BindView(R.id.recycler_view_team)
    RecyclerView mUserRecycler;
    @BindView(R.id.swipe_refresh_container)
    SwipeRefreshLayout mSwipeRefreshContainer;
    @BindView(R.id.text_no_ribots)
    TextView mNoUsrsText;
    @BindView(R.id.progress)
    ProgressBar mProgress;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRetainInstance(true);
        ((BaseActivity) getActivity()).activityComponent().inject(this);
    }

    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container,
                             Bundle savedInstanceState) {
        View fragmentView = inflater.inflate(R.layout.fragment_team, container, false);
        ButterKnife.bind(this, fragmentView);
        mUserRecycler = (RecyclerView)fragmentView.findViewById(R.id.recycler_view_team);
        mSwipeRefreshContainer = (SwipeRefreshLayout)fragmentView.findViewById(R.id.swipe_refresh_container);
        mNoUsrsText = (TextView)fragmentView.findViewById(R.id.text_no_ribots);
        mProgress = (ProgressBar)fragmentView.findViewById(R.id.progress);
        mUserPresenter.attachView(this);
        mUserRecycler.setHasFixedSize(true);
        mUserRecycler.setAdapter(mUserAdapter);
        mSwipeRefreshContainer.setColorSchemeResources(R.color.primary);
        mSwipeRefreshContainer.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                mUserPresenter.loadUsers();
            }
        });
        return fragmentView;
    }

    @Override
    public void onStart() {
        super.onStart();
        mUserPresenter.loadUsers();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mUserPresenter.detachView();
    }

    @Override
    public void showUsers(List<RegisteredUser> users) {
        mUserAdapter.setTeamMembers(users);
        mUserAdapter.notifyDataSetChanged();
        mNoUsrsText.setVisibility(View.GONE);
    }

    @Override
    public void showUsersProgress(boolean show) {
        mSwipeRefreshContainer.setRefreshing(show);
        if (show && mUserAdapter.getItemCount() == 0) {
            mProgress.setVisibility(View.VISIBLE);
        } else {
            mProgress.setVisibility(View.GONE);
        }
    }

    @Override
    public void showEmptyMessage() {
        mNoUsrsText.setVisibility(View.VISIBLE);
    }

    @Override
    public void showUsersError() {
        DialogFactory.createSimpleOkErrorDialog(getActivity(),
                getString(R.string.error_loading_ribots)).show();
    }
}
