package ssms.com.vendorapplication.ui.base;

import android.annotation.TargetApi;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import ssms.com.vendorapplication.VendorApplication;
import ssms.com.vendorapplication.injection.component.ActivityComponent;
import ssms.com.vendorapplication.injection.component.DaggerActivityComponent;
import ssms.com.vendorapplication.injection.module.ActivityModule;

/**
 * Abstract activity that every other Activity in this application must implement. It handles
 * creation of Dagger components and makes sure that instances of ConfigPersistentComponent survive
 * across configuration changes.
 */
public class BaseActivity extends AppCompatActivity {

    private ActivityComponent mActivityComponent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public ActivityComponent activityComponent() {
        if (mActivityComponent == null) {
            mActivityComponent = DaggerActivityComponent.builder()
                    .activityModule(new ActivityModule(this))
                    .applicationComponent(VendorApplication.get(this).getComponent())
                    .build();
        }
        return mActivityComponent;
    }

}
