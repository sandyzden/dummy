package ssms.com.vendorapplication.injection.component;

import dagger.Component;
import ssms.com.vendorapplication.injection.PerActivity;
import ssms.com.vendorapplication.injection.module.ActivityModule;
import ssms.com.vendorapplication.ui.main.MainActivity;
import ssms.com.vendorapplication.ui.LauncherActivity;
import ssms.com.vendorapplication.ui.user.UserFragment;

/**
 * This component inject dependencies to all Activities across the application
 */
@PerActivity
@Component(dependencies = ApplicationComponent.class, modules = ActivityModule.class)
public interface ActivityComponent {

    void inject(MainActivity mainActivity);
    void inject(LauncherActivity launcherActivity);
    void inject(UserFragment userFragment);

}
