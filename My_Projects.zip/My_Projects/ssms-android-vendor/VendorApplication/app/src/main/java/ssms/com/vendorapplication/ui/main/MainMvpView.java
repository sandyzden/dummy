package ssms.com.vendorapplication.ui.main;

import ssms.com.vendorapplication.ui.base.MvpView;

public interface MainMvpView extends MvpView {

    void onSignedOut();

}
