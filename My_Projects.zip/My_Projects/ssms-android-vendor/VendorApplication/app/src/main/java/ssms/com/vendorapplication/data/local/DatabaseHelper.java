package ssms.com.vendorapplication.data.local;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import ssms.com.vendorapplication.data.model.RegisteredUser;

import com.squareup.sqlbrite.BriteDatabase;
import com.squareup.sqlbrite.SqlBrite;

import java.util.Collection;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Singleton;

import rx.Observable;
import rx.Subscriber;
import rx.functions.Func1;
import rx.schedulers.Schedulers;


@Singleton
public class DatabaseHelper {

    private final BriteDatabase mDb;

    @Inject
    public DatabaseHelper(DbOpenHelper dbOpenHelper) {
        SqlBrite.Builder briteBuilder = new SqlBrite.Builder();
        mDb = briteBuilder.build().wrapDatabaseHelper(dbOpenHelper, Schedulers.immediate());
    }

    public BriteDatabase getBriteDb() {
        return mDb;
    }

    public Observable<Void> clearTables() {
        return Observable.create(new Observable.OnSubscribe<Void>() {
            @Override
            public void call(Subscriber<? super Void> subscriber) {
                BriteDatabase.Transaction transaction = mDb.newTransaction();
                try {
                    Cursor cursor = mDb.query("SELECT name FROM sqlite_master WHERE type='table'");
                    while (cursor.moveToNext()) {
                        mDb.delete(cursor.getString(cursor.getColumnIndex("name")), null);
                    }
                    cursor.close();
                    transaction.markSuccessful();
                    subscriber.onCompleted();
                } finally {
                    transaction.end();
                }
            }
        });
    }

    public Observable<Void> setRegisteredUsers(final List<RegisteredUser> users) {
        return Observable.create(new Observable.OnSubscribe<Void>() {
            @Override
            public void call(Subscriber<? super Void> subscriber) {
                BriteDatabase.Transaction transaction = mDb.newTransaction();
                try {
                    mDb.delete(Db.UserProfileTable.TABLE_NAME, null);
                    for (RegisteredUser user : users) {
                        mDb.insert(Db.UserProfileTable.TABLE_NAME,
                                Db.UserProfileTable.toContentValues(user));
                    }
                    transaction.markSuccessful();
                    subscriber.onCompleted();
                } finally {
                    transaction.end();
                }
            }
        });
    }

    public Observable<RegisteredUser> findRegisteredUser(final String id) {
        return Observable.create(new Observable.OnSubscribe<RegisteredUser>() {
            @Override
            public void call(Subscriber<? super RegisteredUser> subscriber) {
                Cursor cursor = mDb.query(
                        "SELECT * FROM " + Db.UserProfileTable.TABLE_NAME +
                                " WHERE " + Db.UserProfileTable.COLUMN_ID + " = ? ",id);
                while (cursor.moveToNext()) {

                    subscriber.onNext(Db.UserProfileTable.parseCursor(cursor));
                }
                cursor.close();
                subscriber.onCompleted();
            }
        });
    }






}
