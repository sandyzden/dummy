package ssms.com.vendorapplication.injection.component;

import android.app.Application;
import android.content.Context;

import com.squareup.otto.Bus;

import javax.inject.Singleton;

import dagger.Component;
import ssms.com.vendorapplication.VendorApplication;
import ssms.com.vendorapplication.data.DataManager;

import ssms.com.vendorapplication.data.local.DatabaseHelper;
import ssms.com.vendorapplication.data.local.PreferencesHelper;
import ssms.com.vendorapplication.data.remote.UnauthorisedInterceptor;
import ssms.com.vendorapplication.data.remote.UserService;
import ssms.com.vendorapplication.injection.ApplicationContext;
import ssms.com.vendorapplication.injection.module.ApplicationModule;


@Singleton
@Component(modules = ApplicationModule.class)
public interface ApplicationComponent {

    void inject(VendorApplication application);
    void inject(UnauthorisedInterceptor unauthorisedInterceptor);

    @ApplicationContext Context context();
    Application application();
    UserService userService();
    PreferencesHelper preferencesHelper();
    DatabaseHelper databaseHelper();
    DataManager dataManager();
    Bus eventBus();

}
