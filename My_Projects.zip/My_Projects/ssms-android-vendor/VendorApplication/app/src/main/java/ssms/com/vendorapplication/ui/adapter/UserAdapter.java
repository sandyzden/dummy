package ssms.com.vendorapplication.ui.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

//import com.bumptech.glide.Glide;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import ssms.com.vendorapplication.R;
import ssms.com.vendorapplication.data.model.RegisteredUser;
import ssms.com.vendorapplication.util.DateUtil;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.UserHolder> {
    private List<RegisteredUser> mTeamMembers;

    @Inject
    public UserAdapter() {
        this.mTeamMembers = new ArrayList<>();
    }

    @Override
    public UserHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view =
                LayoutInflater.from(parent.getContext()).inflate(R.layout.item_team, parent, false);
        return new UserHolder(view);
    }

    @Override
    public void onBindViewHolder(final UserHolder holder, final int position) {
        RegisteredUser user = mTeamMembers.get(position);
        holder.id.setText(user.id);
        holder.userId.setText(user.userId);
        holder.title.setText(user.title);
        holder.body.setText(user.body);
    }

    @Override
    public int getItemCount() {
        return mTeamMembers.size();
    }

    public void setTeamMembers(List<RegisteredUser> list) {
        mTeamMembers = list;
    }

    class UserHolder extends RecyclerView.ViewHolder {

        //@BindView(R.id.layout_container)
        public RelativeLayout layoutContainer;

        //@BindView(R.id.id)
        public TextView id;

        //@BindView(R.id.userId)
        public TextView userId;

        //@BindView(R.id.title)
        public TextView title;

        //@BindView(R.id.body)
        public TextView body;



        public UserHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
            layoutContainer = (RelativeLayout) itemView.findViewById(R.id.layout_container);
            id = (TextView) itemView.findViewById(R.id.id);
            userId = (TextView) itemView.findViewById(R.id.userId);
            title = (TextView) itemView.findViewById(R.id.title);
            body = (TextView) itemView.findViewById(R.id.body);
        }
    }

}