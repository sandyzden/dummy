# spring-boot-microservice-config
Configuration repository for Spring Cloud microservice example
