-- MySQL dump 10.13  Distrib 5.6.22, for osx10.8 (x86_64)
--
-- Host: localhost    Database: SSMS
-- ------------------------------------------------------
-- Server version	5.6.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Billing`
--

DROP TABLE IF EXISTS `billing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `billing` (
  `billingid` decimal(5,0) NOT NULL,
  `sbookid` decimal(5,0) DEFAULT NULL,
  `sservicecharge` decimal(10,2) DEFAULT NULL,
  `stotalprice` decimal(10,2) DEFAULT NULL,
  `pymtmethod` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`billingid`),
  KEY `fk_billing` (`sbookid`),
  CONSTRAINT `fk_billing` FOREIGN KEY (`sbookid`) REFERENCES `ssbookings` (`ssid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Billing`
--

LOCK TABLES `billing` WRITE;
/*!40000 ALTER TABLE `Billing` DISABLE KEYS */;
/*!40000 ALTER TABLE `Billing` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PartBilling`
--

DROP TABLE IF EXISTS `partbilling`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `partbilling` (
  `sbookid` decimal(5,0) NOT NULL,
  `partid` decimal(5,0) NOT NULL,
  `partcost` decimal(10,2) DEFAULT '0.00',
  KEY `fk_partbilling_1` (`sbookid`),
  KEY `fk_partbilling_2` (`partid`),
  CONSTRAINT `fk_partbilling_1` FOREIGN KEY (`sbookid`) REFERENCES `ssbookings` (`sbookid`),
  CONSTRAINT `fk_partbilling_2` FOREIGN KEY (`partid`) REFERENCES `parts` (`partid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PartBilling`
--

LOCK TABLES `partbilling` WRITE;
/*!40000 ALTER TABLE `PartBilling` DISABLE KEYS */;
/*!40000 ALTER TABLE `PartBilling` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Parts`
--

DROP TABLE IF EXISTS `parts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `parts` (
  `partid` decimal(5,0) NOT NULL,
  `partname` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`partid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Parts`
--

LOCK TABLES `parts` WRITE;
/*!40000 ALTER TABLE `Parts` DISABLE KEYS */;
/*!40000 ALTER TABLE `Parts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SSBookings`
--

DROP TABLE IF EXISTS `ssbookings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ssbookings` (
  `sbookid` decimal(5,0) NOT NULL,
  `ssid` decimal(5,0) NOT NULL,
  `userid` decimal(5,0) DEFAULT NULL,
  `vmodelid` decimal(5,0) DEFAULT NULL,
  `bookingdate` datetime DEFAULT NULL,
  `remarks` varchar(100) DEFAULT NULL,
  `exdelivery` datetime DEFAULT NULL,
  `estimatedquote` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`sbookid`),
  KEY `fk_book_ssid` (`ssid`),
  KEY `fk_booking_vmodel` (`vmodelid`),
  CONSTRAINT `fk_book_ssid` FOREIGN KEY (`ssid`) REFERENCES `ssdetails` (`ssid`),
  CONSTRAINT `fk_booking_vmodel` FOREIGN KEY (`vmodelid`) REFERENCES `vmodel` (`vmodelid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SSBookings`
--

LOCK TABLES `ssbookings` WRITE;
/*!40000 ALTER TABLE `SSBookings` DISABLE KEYS */;
/*!40000 ALTER TABLE `SSBookings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SSCredentials`
--

DROP TABLE IF EXISTS `sscredentials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sscredentials` (
  `ssid` decimal(5,0) NOT NULL,
  `sspasswordkey` varchar(25) NOT NULL,
  `ssdeviceid` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`ssid`),
  CONSTRAINT `fK_sslogin` FOREIGN KEY (`ssid`) REFERENCES `ssdetails` (`ssid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SSCredentials`
--

LOCK TABLES `sscredentials` WRITE;
/*!40000 ALTER TABLE `SSCredentials` DISABLE KEYS */;
INSERT INTO `sscredentials` VALUES (1,'abcdefgiklmno','SAMD-EF');
/*!40000 ALTER TABLE `SSCredentials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SSReviews`
--

DROP TABLE IF EXISTS `ssreviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ssreviews` (
  `ssreviewid` decimal(5,0) NOT NULL,
  `userid` decimal(5,0) DEFAULT NULL,
  `ssid` decimal(5,0) DEFAULT NULL,
  `srating` decimal(2,0) DEFAULT NULL,
  `scomment` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`ssreviewid`),
  KEY `fk_ssreview_ssid` (`ssid`),
  CONSTRAINT `fk_ssreview_ssid` FOREIGN KEY (`ssid`) REFERENCES `ssdetails` (`ssid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SSReviews`
--

LOCK TABLES `ssreviews` WRITE;
/*!40000 ALTER TABLE `SSReviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `SSReviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SSTimings`
--

DROP TABLE IF EXISTS `sstimings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sstimings` (
  `ssid` decimal(5,0) NOT NULL,
  `weekstartday` varchar(10) DEFAULT NULL,
  `weekendday` varchar(10) DEFAULT NULL,
  `opentime` varchar(8) DEFAULT NULL,
  `closetime` varchar(8) DEFAULT NULL,
  `slottiming` decimal(3,0) DEFAULT NULL,
  PRIMARY KEY (`ssid`),
  CONSTRAINT `fk_sstiming` FOREIGN KEY (`ssid`) REFERENCES `ssdetails` (`ssid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SSTimings`
--

LOCK TABLES `sstimings` WRITE;
/*!40000 ALTER TABLE `SSTimings` DISABLE KEYS */;
INSERT INTO `sstimings` VALUES (1,'Monday','Saturday','10:00','7;00',30);
/*!40000 ALTER TABLE `SSTimings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SServicesList`
--

DROP TABLE IF EXISTS `sserviceslist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sserviceslist` (
  `sbookid` decimal(5,0) NOT NULL,
  `serviceid` decimal(5,0) DEFAULT NULL,
  KEY `fk_sslist_sbookid` (`sbookid`),
  KEY `fk_service_serviceid` (`serviceid`),
  CONSTRAINT `fk_service_serviceid` FOREIGN KEY (`serviceid`) REFERENCES `services` (`serviceid`),
  CONSTRAINT `fk_sslist_sbookid` FOREIGN KEY (`sbookid`) REFERENCES `ssbookings` (`ssid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SServicesList`
--

LOCK TABLES `sserviceslist` WRITE;
/*!40000 ALTER TABLE `SServicesList` DISABLE KEYS */;
/*!40000 ALTER TABLE `SServicesList` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SSpeicality`
--

DROP TABLE IF EXISTS `sspeicality`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sspeicality` (
  `specialityid` decimal(5,0) NOT NULL,
  `ssid` decimal(5,0) NOT NULL,
  KEY `fk_sspeciality_1` (`ssid`),
  KEY `fk_sspeciality_2` (`SpecialityID`),
  CONSTRAINT `fk_sspeciality_1` FOREIGN KEY (`ssid`) REFERENCES `ssdetails` (`ssid`),
  CONSTRAINT `fk_sspeciality_2` FOREIGN KEY (`specialityid`) REFERENCES `speciality` (`specialityid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SSpeicality`
--

LOCK TABLES `sspeicality` WRITE;
/*!40000 ALTER TABLE `SSpeicality` DISABLE KEYS */;
INSERT INTO `sspeicality` VALUES (1,1),(2,1);
/*!40000 ALTER TABLE `SSpeicality` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Services`
--

DROP TABLE IF EXISTS `services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `services` (
  `serviceid` decimal(5,0) NOT NULL,
  `servicename` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`serviceid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Services`
--

LOCK TABLES `services` WRITE;
/*!40000 ALTER TABLE `Services` DISABLE KEYS */;
/*!40000 ALTER TABLE `Services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Speciality`
--

DROP TABLE IF EXISTS `speciality`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `speciality` (
  `specialityid` decimal(5,0) NOT NULL,
  `specialityname` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`specialityid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Speciality`
--

LOCK TABLES `speciality` WRITE;
/*!40000 ALTER TABLE `Speciality` DISABLE KEYS */;
INSERT INTO `speciality` VALUES (1,'Servicing'),(2,'Washing'),(3,'Electricals');
/*!40000 ALTER TABLE `Speciality` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `VManufacturer`
--

DROP TABLE IF EXISTS `vmanufacturer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vmanufacturer` (
  `vmanid` decimal(5,0) NOT NULL,
  `vmanname` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`vmanid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VManufacturer`
--

LOCK TABLES `vmanufacturer` WRITE;
/*!40000 ALTER TABLE `VManufacturer` DISABLE KEYS */;
/*!40000 ALTER TABLE `VManufacturer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `VModel`
--

DROP TABLE IF EXISTS `vmodel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vmodel` (
  `vmodelid` decimal(5,0) NOT NULL DEFAULT '0',
  `vmanid` decimal(5,0) DEFAULT NULL,
  `vmodelname` varchar(25) DEFAULT NULL,
  `vmodelcc` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`vmodelid`),
  KEY `fk_manufacture` (`vmanid`),
  CONSTRAINT `fk_manufacture` FOREIGN KEY (`vmanid`) REFERENCES `VManufacturer` (`vmanid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VModel`
--

LOCK TABLES `vmodel` WRITE;
/*!40000 ALTER TABLE `VModel` DISABLE KEYS */;
/*!40000 ALTER TABLE `VModel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ssdetails`
--

DROP TABLE IF EXISTS `ssdetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ssdetails` (
  `ssid` decimal(5,0) NOT NULL,
  `ssname` varchar(30) NOT NULL,
  `ssaddress` varchar(100) DEFAULT NULL,
  `sslocation` varchar(50) DEFAULT NULL,
  `sscity` varchar(50) DEFAULT NULL,
  `sslongitude` varchar(25) DEFAULT NULL,
  `sslattitude` varchar(25) DEFAULT NULL,
  `sscontactno` varchar(12) DEFAULT NULL,
  `ssownername` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`ssid`),
  KEY `IDX_SSID` (`ssid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ssdetails`
--

LOCK TABLES `ssdetails` WRITE;
/*!40000 ALTER TABLE `ssdetails` DISABLE KEYS */;
INSERT INTO `ssdetails` VALUES (1,'Sample Service Station','No 45, mosque road','Frazer town','Bangalore','12.78989','78.389000','8880005578','Mohammed Raees',NULL);
/*!40000 ALTER TABLE `ssdetails` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-01-14 11:07:35
