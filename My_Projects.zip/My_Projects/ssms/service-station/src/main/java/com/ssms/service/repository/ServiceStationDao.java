package com.ssms.service.repository;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Map;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import org.springframework.data.repository.CrudRepository;

import com.ssms.service.models.ServiceStation;
import com.ssms.service.models.ServiceStation;


@Transactional
public interface ServiceStationDao extends CrudRepository<ServiceStation, Long> {

  /**
   * Return the user having the passed email or null if no user is found.
   * 
   * @param email the user email.
   */
  public ServiceStation findBySsid(long ssid);

 // @Query("SELECT ssid FROM ServiceStation")
 // public List<ServiceStation> findBySsname(@Param("ssname") String ssname);  
 
  public List<ServiceStation> findAll();
  
  
  public List<ServiceStation> findBySsnameContaining(String ssname);
  
  public List<ServiceStation> findBySscityContaining(String sscity);
  
 // @Query("SELECT t1 FROM ServiceStation t1 inner join ServiceStation t2 ON t1.ssid = t2.ssid inner join Speciality t3 ON t2.specialityid = t3.specialityid")
//  public List<ServiceStation> findBySspeciality(@Param("specialityname") String specialityname);

} // class UserDao
