package com.ssms.service.repository;

import javax.transaction.Transactional;
import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;
import org.springframework.data.repository.CrudRepository;

import com.ssms.service.models.StationSpeciality;

@Transactional
public interface StationSpecialityDao extends CrudRepository<StationSpeciality, Long> {

  /**
   * Return the user having the passed email or null if no user is found.
   * 
   * @param email the user email.
   */
  public List<StationSpeciality> findBySsid(long ssid);


} // class UserDao
