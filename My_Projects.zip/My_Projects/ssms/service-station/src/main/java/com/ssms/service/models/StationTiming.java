package com.ssms.service.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "sstimings")
public class StationTiming
{

 @Id
 private long ssid;
 
 private String weekstartday;
  
 private String weekendday;
  
 private String opentime;
  
 private String closetime;
  
 private long slottiming;
 
 public StationTiming() { }
 
 public long getSSID() {
    return ssid;
  }

  public void setSSID(long ssid) {
    this.ssid = ssid;
  }
  
  public String getWeekStartDay()
  {
  	return weekstartday;
  }
  
  public void setWeekStartDay(String weekstartday)
  {
  	this.weekstartday = weekstartday;
  }
  
  public String getWeekEndDay()
  {
  	return weekendday;
  }
  
  public void setWeekEndDay(String weekendday)
  {
  	this.weekendday = weekendday;
  }
  
  public String getOpenTime()
  {
  	return opentime;
  }
  
  public void setOpenTime(String opentime)
  {
  	this.opentime = opentime;
  }
  
  public String getCloseTime()
  {
  	return closetime;
  }
  
  public void setCloseTime(String closetime)
  {
  	this.closetime = closetime;
  }
  
  public long getSlotTiming()
  {
  	return slottiming;
  }
  
  public void setSlotTiming(long slottiming)
  {
  	this.slottiming = slottiming;
  }
  
  



}