package com.ssms.service.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.persistence.*;

@Entity
@Table(name = "speciality")
public class Speciality
{

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  private long specialityid;
  
  private String specialityname;
  
  public Speciality() { }
  
  public long getSpecialityId()
  {
  	return specialityid;
  }
  
  public void setSpecialityId(long specialityid)
  {
  	this.specialityid = specialityid;
  }

  public String getSpecialityName()
  {
  	return specialityname;
  }
  
  public void setSpecialityName(String specialityname)
  {
  	this.specialityname = specialityname;
  }

}