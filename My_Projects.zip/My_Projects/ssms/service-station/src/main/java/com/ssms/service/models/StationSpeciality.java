package com.ssms.service.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "sspeciality")
@IdClass(StationSpecialityId.class)
public class StationSpeciality implements Serializable
{

  @Id
  private long specialityid;
  @Id
  private long ssid;
  
  @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
  @JoinColumn(name="specialityid", nullable=false,insertable=false, updatable=false)
  private Speciality speciality;
  
  public long getSpecialityId()
  {
  		return specialityid;
  }
  
  public void setSpecialityId(long specialityid)
  {
  		this.specialityid = specialityid;
  }
  
  public long getSSID()
  {
  	 return ssid;
  }
  
  public void setSSID(long ssid)
  {
  		this.ssid = ssid;
  }
  
  public Speciality getSpeciality()
  {
  		return speciality;
  }
  
  public void setSpeciality(Speciality speciality)
  {
  		this.speciality = speciality;
  }
  
  
}
 class StationSpecialityId implements Serializable
{
	 private long specialityid;
	 private long ssid;
}